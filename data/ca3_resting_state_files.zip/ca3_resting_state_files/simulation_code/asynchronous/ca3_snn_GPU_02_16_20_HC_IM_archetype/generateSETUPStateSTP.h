sim.setSpikeMonitor(CA3_Basket, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_MFA_ORDEN, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_Pyramidal, "DEFAULT");
                                 
