sim.setSpikeMonitor(CA3_QuadD_LM, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_Axo_Axonic, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_Basket, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_BC_CCK, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_Bistratified, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_Ivy, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_MFA_ORDEN, "DEFAULT");
                                 
sim.setSpikeMonitor(CA3_Pyramidal, "DEFAULT");
                                 
